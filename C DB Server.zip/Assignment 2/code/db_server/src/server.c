#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/errno.h>
#include <arpa/inet.h>
#include <signal.h>
#include <string.h>

//for file functions
#include <dirent.h>
#include <sys/file.h>
#include <fcntl.h>

// for request lib
#include "../include/request.h"

// for waitpid
#include <sys/wait.h>

#define DIE(str) \
	perror(str); \
	exit(-1);

#define BUFSIZE 255

int file_exists(const char *filename)
{
	FILE *file;
	if ((file = fopen(filename, "r")))
	{
		fclose(file);
		return 1;
	}
	return 0;
}

/**
 * First things first, we need the table
 * for this, we need file pointers to the files alltables, tableschema and tabladata
 * 
 * The concept here is to have a variable loop through the files for an empty file.
 * Not look, but have to make. An existing file will be source of conflict.
 * We have 3 files, all_table.txt for recording names of all tables
 * We will make another file with the table name and append the _schema.txt to it to 
 * store table specific schema.
 * In the third one, we will insert records of that specific table.
*/

char *create_table(request_t *request)
{
	FILE *allTables;
	FILE *tableSchema;
	FILE *tableContent;

	// Return value
	char *ret = malloc(sizeof(char) * 255);
	memset(ret, 0, sizeof ret);

	// Allocating memory and creating the three files.
	char line[255];
	char *checkEmpty = malloc(sizeof(char) * 255);
	memset(ret, 0, sizeof ret);

	char *fileName = "../database/tables_list.txt";

	char fileSchema[255] = "../database/";
	strncat(fileSchema, request->table_name, strlen(request->table_name));
	strncat(fileSchema, "_schema.txt", strlen("_schema.txt"));

	char fileContent[255] = "../database/";
	strncat(fileContent, request->table_name, strlen(request->table_name));
	strncat(fileContent, "_contents.txt", strlen("_contents.txt"));

	if (file_exists(fileSchema) == 0)
	{
		//If the file exists, we want to write something to it. We want it to not
		// exist hence we are checking the ==0
		// Here, a write specific lock has been implemented. Only 1 can write, many can read
		// source https://www.gnu.org/software/libc/manual/html_node/File-Locks.html

		struct flock lock;
		memset(&lock, 0, sizeof(lock));
		lock.l_type = F_WRLCK;
		int lock1 = -1;

		//lock control mechanism while we append/write to file
		while (lock1 != 0)
		{
			allTables = fopen(fileName, "a");
			//https://man7.org/linux/man-pages/man2/fcntl.2.html
			//recall only 1 can write, as such we are trying to control that pool.
			lock1 = fcntl(fileno(allTables), F_SETLK, &lock); //manipulates the file descriptor
		}
		//opening other files in append as well.
		tableSchema = fopen(fileSchema, "a");
		tableContent = fopen(fileContent, "a");

		// read each line of the provided file in the file variable
		while (fgets(line, sizeof(line), tableSchema) != NULL)
		{
			strncat(checkEmpty, line, sizeof(line));
		}
		free(checkEmpty);
		//set the position indicator of stream, boy was this confusing to understand
		//fseek is trying to reach end of file
		fseek(tableSchema, 0, SEEK_END);
		//if current position of stream is 0, or eof, why we called fseek above.
		// anything else means table exists

		if (ftell(tableSchema) == 0)
		{
			//add table name to the file
			fprintf(allTables, "%s\n", request->table_name);

			//Set the first request column to loop
			column_t *current = request->columns;

			// Addint data to the table schema, release lock at the end
			while (current != NULL)
			{
				fprintf(tableSchema, "%s\t", current->name);

				if (current->data_type == 0)
				{
					fprintf(tableSchema, "INT");
				}
				else
				{
					fprintf(tableSchema, "VARCHAR(%i)", current->char_size);
				}

				fprintf(tableSchema, "\n");
				current = current->next;
			}
			lock.l_type = F_UNLCK;
			fcntl(fileno(allTables), F_SETLK, &lock);
			strcat(ret, "Succesfully created\n");
		}
		else
		{
			strcat(ret, "Table already exists\n");
		}
		//close the streams
		fclose(tableSchema);
		fclose(tableContent);
		fclose(allTables);
	}
	else
	{
		strcat(ret, "Table already exists\n");
	}
	return ret;
}

/**
 * table schema is essentially a file reader
 * What we have to do is point read that file but with the proper name along with the 
 * text we appended for its identification, set the appropriate memory and check if file exists.
 * if it does, simply loop through the contents.
*/
char *table_schema(request_t *request)
{
	char fileName[255] = "../database/";
	strncat(fileName, request->table_name, strlen(request->table_name));
	strncat(fileName, "_schema.txt", strlen("_schema.txt"));

	char line[255];
	char *ret = malloc(sizeof(char) * 255);
	memset(ret, 0, sizeof ret);

	if (file_exists(fileName) == 1)
	{
		FILE *tableSchema = fopen(fileName, "r");
		while (fgets(line, sizeof(line), tableSchema) != NULL)
		{ // read each line of the provided file in the file variable
			strncat(ret, line, sizeof(line));
		}
		fclose(tableSchema);
	}
	else
	{
		strcat(ret, "Cannot display schema of undefined table\n");
	}

	return ret;
}

/**
 * conceptually like table schema but we have it simpler here.
 * just read a single all_table file here and if there are no tables yet,
 * then prompt as so.
*/
char *all_tables()
{
	char *fileName = "../database/tables_list.txt";

	char line[255];
	char *ret = malloc(sizeof(char) * 255);
	memset(ret, 0, sizeof ret);

	if (file_exists(fileName) == 1)
	{
		FILE *allTables = fopen(fileName, "r");
		while (fgets(line, sizeof(line), allTables) != NULL)
		{ // read each line of the provided file in the file variable
			strncat(ret, line, sizeof(line));
		}
		fseek(allTables, 0, SEEK_END);
		if (ftell(allTables) == 0)
		{
			strcat(ret, "Database empty\n");
		}
		fclose(allTables);
	}
	else
	{
		strcat(ret, "Database empty\n");
	}

	return ret;
}

/**
 * Time for some file modification, we have to remove a table from the all_tables file
 * and remove its corresponding 
 * What we are doing is locatnig the name of the table in the all_tables file.
 * We have copied that file in read and its temporary version in write mode
 * we loop through the file and add data to the temp unless its the line we want.
 * Now at the end, we remove the schema and data file of that table, and remove the original
 * all tables file and rename our temp file as all_tables and that is it.
*/
char *drop_table(request_t *request)
{
	char *fileName = "../database/tables_list.txt";
	char *temp = "../database/temp.txt";

	FILE *allTables;
	FILE *tempFile;

	int found = 0; // flag variable to find the table we want.
	char *ret = malloc(sizeof(char) * 255);
	memset(ret, 0, sizeof ret);

	if (file_exists(fileName) == 1)
	{
		struct flock lock;
		memset(&lock, 0, sizeof(lock));
		lock.l_type = F_WRLCK;
		int lock1 = -1;

		while (lock1 != 0)
		{
			// set the modes and add the write exclusive lock
			allTables = fopen(fileName, "r");
			tempFile = fopen(temp, "w");
			lock1 = fcntl(fileno(tempFile), F_SETLK, &lock);
		}
		char line[255];
		char *pos;

		while (fgets(line, sizeof(line), allTables) != NULL)
		{ // read each line of the provided file in the file variable
			if ((pos = strchr(line, '\n')) != NULL)
				*pos = '\0';
			//print values if the line is not the table to be deleted
			if (strcmp(line, request->table_name) != 0)
			{
				fprintf(tempFile, "%s\n", line);
				fflush(tempFile); //clear buffer, move to stdout
			}
			else
			{
				found = 1;
			}
		}

		if (found == 1)
		{
			char first[255] = "../database/";
			strncat(first, request->table_name, strlen(request->table_name));
			strncat(first, "_contents.txt", strlen("_contents.txt"));

			char second[255] = "../database/";
			strncat(second, request->table_name, strlen(request->table_name));
			strncat(second, "_schema.txt", strlen("_schema.txt"));

			remove(first);
			remove(second);
			remove(fileName);
			rename(temp, fileName);
			strcat(ret, "Table dropped\n");
		}
		else
		{
			strcat(ret, "Table does not exist\n");
		}

		lock.l_type = F_UNLCK;
		fcntl(fileno(tempFile), F_SETLK, &lock);

		fclose(allTables);
		fclose(tempFile);
	}
	else
	{
		strcat(ret, "No tables in the database\n");
	}
	return ret;
}

/**
 * the first parts are similar to what already has been done over and over
 * get the appropriate file name, set the buffer, 
 * check if file exists and append it and set a write lock on the file
 * thanks to the request library, what we have to do is look at the request
 * or insert statement column name, type and size, seperated by int, varchar.
 * checks if lock is availble to write else waits for condition to be satisied
 * if all is good, it prints the values in the data file, thus inserting.
 */
char *insert_values(request_t *request)
{
	FILE *tableContent;
	char fileName[255] = "../database/";
	strncat(fileName, request->table_name, strlen(request->table_name));
	strncat(fileName, "_contents.txt", strlen("_contents.txt"));

	char *ret = malloc(sizeof(char) * 255);
	memset(ret, 0, sizeof ret);

	if (file_exists(fileName) == 1)
	{
		tableContent = fopen(fileName, "a");
		struct flock lock;
		memset(&lock, 0, sizeof(lock));
		lock.l_type = F_WRLCK;
		//if lock1=-1, it means fcntl could not set an exclusive lock
		// wait until can get again and as such, a recursive call is issued.
		int lock1 = fcntl(fileno(tableContent), F_SETLK, &lock);
		if (lock1 != -1)
		{
			column_t *current = request->columns;
			//Loop through all columns and add column name and type + char_size
			while (current != NULL)
			{
				if (current->data_type == 0)
				{
					fprintf(tableContent, "%i\t", current->int_val);
				}
				else
				{
					fprintf(tableContent, "%s\t", current->char_val);
				}
				current = current->next;
			}
		}
		else
		{
			insert_values(request);
		}
		fprintf(tableContent, "\n");
		lock.l_type = F_UNLCK;
		fcntl(fileno(tableContent), F_SETLK, &lock);
		fclose(tableContent);
		strcat(ret, "Row Inserted\n");
	}
	else
	{
		strcat(ret, "The table '");
		strcat(ret, request->table_name);
		strcat(ret, "' does not exist\n");
	}
	return ret;
}

/**
 * This is again, conceptually a read process.
 * The task at hand is to get the appropriate file first.
 * After that is done, loopthrough the contents of the file.
*/
char *select_values(request_t *request)
{

	FILE *tableContent;
	char line[255];
	char *ret = malloc(sizeof(char) * 255);
	memset(ret, 0, sizeof ret); // memset the ret string, it will contain weird chars in ret[0] otherwise

	char fileName[255] = "../database/";
	strncat(fileName, request->table_name, strlen(request->table_name));
	strncat(fileName, "_contents.txt", strlen("_contents.txt"));

	if (file_exists(fileName) == 1)
	{
		tableContent = fopen(fileName, "r");
		while (fgets(line, sizeof(line), tableContent) != NULL)
		{ // read each line of the provided file in the file variable
			strncat(ret, line, sizeof(line));
		}
		fseek(tableContent, 0, SEEK_END);
		if (ftell(tableContent) == 0)
		{
			strcat(ret, "No data inside the table\n");
		}
		fclose(tableContent);
	}
	else
	{

		strcat(ret, "The table '");
		strcat(ret, request->table_name);
		strcat(ret, "' does not exist\n");
	}
	return ret;
}

// -----------------------------------------------------------------------------------------------------

int server; // global server socket since we shut it down using a sighandler
int client; // global client socket since we shut it down using a sighandler (if needed)

// when child terminates the parent gets signal and call this function to terminate the process
void sighandler()
{
	while (waitpid(-1, NULL, WNOHANG) > 0)
	{ // -1 = wait for any child, WNOHANG = don't block if the state isn't changed (man waitpid)
		continue;
	}
	puts("Child process terminated");
}

// when the server gets interrupted via <ctrl+c> we shut down and exit the server process
void interrupthandler()
{
	if (shutdown(server, SHUT_RDWR) != 0)
	{ // if the server couldn't be shut down
		if (shutdown(client, SHUT_RDWR) == 0)
		{								 // try to shutdown the client, if it works
			close(client);				 // close clientsocket
			shutdown(server, SHUT_RDWR); // shutdown serversocket again
			close(server);				 // close serversocket
		}
	}
	else
	{
		close(server); // if the serversocket could be shut down, close it
	}
	exit(0);
}

int main(int argc, char *argv[])
{
	int portnumber = 3306; // default port, using mysql def port
	
	struct sockaddr_in sin, pin;
	int addrlen;
	char buf[BUFSIZE];
	pid_t pid;

	if (argc < 1 || argc > 3)
	{
		fprintf(stderr, "Usage: %s -p <port>\n", argv[0]);
		exit(-1);
	}

	int i;
	for (i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "-h") == 0)
		{
			printf("Usage: %s -p <port> or %s\n", argv[0],argv[0]);
			puts("-h print help text.");
			puts("-p listen to port number <port>.");
			exit(0);
		}
		else if (strcmp(argv[i], "-p") == 0)
		{
			if (argv[i + 1] != NULL)
				portnumber = atoi(argv[i + 1]);
			else
			{
				printf("Usage: %s -p <port>\n", argv[0]);
				exit(0);
			}
		}
		else if (strcmp(argv[i], "-d") == 0 || strcmp(argv[i], "-l") == 0 || strcmp(argv[i], "-s") == 0)
		{
			printf("Usage: %s -p <port> or %s\n", argv[0],argv[0]);
			puts("-h print help text.");
			puts("-p listen to port number <port>.");
			exit(3);
		}
	}

	printf("BQL Server e Yokoso\n");
	printf("Server started at port %i\n", portnumber);
	printf("------\n");

	/* get a file descriptor for an IPv4 socket using TCP */
	if ((server = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		DIE("socket");
	}

	/* set the port to be reusable */
	int option = 1;
	setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));

	/* zero out the sockaddr_in struct */
	memset(&sin, 0, sizeof(sin));
	/* setup the struct to inform the operating system that we would like
         * to bind the socket the the given port number on any network
         * interface using IPv4 */
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = htons(portnumber);

	/* perform bind call */
	if (bind(server, (struct sockaddr *)&sin, sizeof(sin)) == -1)
	{
		DIE("bind");
	}

	listen(server, 1); 
	/* there wont be any connections waiting since we fork each new client.
	The second argument essentially controls the size of the waiting queue for
	accepting the request. Fork will cause client to not wait and am not to keen
	to control that mechanism at this moment LOL, so 1 or 10 or 100, the sky is the
	limit, so yeah, still setting value to 5 but empirically works with any thanks to 
	the fork (RIP system resources)*/

	addrlen = sizeof(pin);

	//https://stackoverflow.com/questions/30799296/what-does-signalsigpipe-sig-ign-do
	//so that is how you handle the zombies. Could use a SIGTERM or SIGKILL? Better test later.
	//prevent write to socket that had been shutdown for writing or isn't connected (anymore).
	signal(SIGCHLD, sighandler);
	signal(SIGINT, interrupthandler);

	while (1)
	{
		// accept connection
		client = accept(server, (struct sockaddr *)&pin, (socklen_t *)&addrlen);

		// clean the buffer, strange chars will appear in the server console otherwise.
		memset(buf, 0, sizeof buf);
		if ((pid = fork()) == -1)
		{ 	//<0 means the child process was not made, >0 is child, ==0 ret to child
			//https://stackoverflow.com/questions/4160347/close-vs-shutdown-socket
			// way to block send/receive, with shut rdwr meaning some file operation going so stop it. Recommended as seen.
			shutdown(client, SHUT_RDWR);
			shutdown(server, SHUT_RDWR);
			close(client); // actually destroys the socket.
			close(server);
			continue;
		}
		else if (pid == 0)
		{ // in child process // the parent process doesn't need to to anything after this, since we're waiting for the SIGCHILD signal
			close(server);
			char ipAddress[INET_ADDRSTRLEN];
			inet_ntop(AF_INET, &pin.sin_addr, ipAddress, sizeof(ipAddress));
			printf("\nClient connected at %s:%i\n", ipAddress, ntohs(pin.sin_port));
			while (1)
			{

				// receive at most sizeof(buf) many bytes and store them in the buffer// when all the bytes are received
				if (recv(client, buf, sizeof(buf), 0) == -1)
				{
					DIE("recv");
				}

				/* convert IP address of communication partner to string */

				// print the buf to server terminal
				printf("%s:%i - %s\n", ipAddress, ntohs(pin.sin_port), buf);

				// error handeling var
				char *error;

				// create the request and parse it
				request_t *request;

				request = parse_request(buf, &error);

				if (request == NULL)
				{ // if there was an error with the request, tell the client and free the error
					send(client, error, strlen(error) + 1, 0);
					send(client, "\n", strlen("\n") + 1, 0);
					free(error);
					shutdown(client, SHUT_RDWR);
					close(client);
					exit(0);
				}

				char *returnVal;

				switch (request->request_type)
				{
				case RT_CREATE:

					//do I use send or write()
					//socketfile descriptor, buffer, buffer len, flag, 0 is write(). Any guarentee of write to disk?
					// send without flag is interestingly write. send with flag =0 is write().
					// obviously stpid argument really. send() is used here for network purposes. Although the command 
					// being executed is on server
					// write writes to file desfiptor, send() sends message on socket. both ssize_t (unsigned size_t)
					// you know what, send() wins. Lets stay as true to network as possible
					//https://linux.die.net/man/2/write https://linux.die.net/man/2/send
					returnVal = create_table(request);					
					send(client, returnVal, strlen(returnVal) + 1,0);
					free(returnVal);
					break;

				case RT_TABLES:
					returnVal = all_tables();
					printf("%d", request->request_type);
					send(client, returnVal, strlen(returnVal) + 1,0);
					free(returnVal);
					break;

				case RT_SCHEMA:
					returnVal = table_schema(request);
					send(client, returnVal, strlen(returnVal) + 1,0);
					free(returnVal);
					break;

				case RT_DROP:
					returnVal = drop_table(request);
					send(client, returnVal, strlen(returnVal) + 1,0);
					free(returnVal);
					break;

				case RT_INSERT:
					returnVal = insert_values(request);
					send(client, returnVal, strlen(returnVal) + 1,0);
					free(returnVal);
					break;

				case RT_SELECT:
					returnVal = select_values(request);
					send(client, returnVal, strlen(returnVal) + 1,0);
					free(returnVal);
					break;

				case RT_QUIT:
					printf("Closing socket %s:%i per client request.\n", ipAddress, ntohs(pin.sin_port));
					shutdown(client, SHUT_RDWR);
					close(client);
					exit(0);
					break;

				default:
					break;
				}

				destroy_request(request);
				memset(buf, 0, sizeof buf); //memset 0, basically cleans
			}
		}
	}
	exit(0);
}